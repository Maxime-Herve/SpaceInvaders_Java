package v3.etu;

// LanceurV2 fourni
public class LanceurV3 {
	public static void main(String[] args) throws InterruptedException {
		// initialisation du log
		Log.createLog();
		// Creation de l'objet jeu et initialisation
		Jeu jeu = new Jeu();
		// lancement de la boucle de jeu
		jeu.boucleJeu();
		// fermeture du log
		Log.close();
	}
}
