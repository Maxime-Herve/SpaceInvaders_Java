package v3.etu;

/**
 * Declaration des ressources. Chaque élément graphique dispose d'un code On
 * peut associer une texture (= image) à chaque élément graphique
 * 
 * Certains code/texture sont en commentaire, ils sont à activer pour utiliser
 * plusieurs lignes d'Aliens
 * 
 * Les aliens ont deux codes r et R et deux textures AlienR1.png et AlienR2.png
 * afin de permettre une animation
 * 
 */
public class Constantes {

	public static final char code_vaisseau = '@';
	public static final char code_projectile = '|';

	public static final char code_alien_rouge = 'r';
	public static final char code_alien_rouge_alt = 'R';
	public static final char code_alien_vert = 'v';
	public static final char code_alien_vert_alt = 'V';
	public static final char code_alien_jaune = 'j';
	public static final char code_alien_jaune_alt = 'J';

	public static final String tx_vaisseau = "./ressources/Vaisseau.png";
	public static final String tx_projectile = "./ressources/Projectile.png";

	public static final String tx_alien_rouge = "./ressources/AlienR1.png";
	public static final String tx_alien_rouge_alt = "./ressources/AlienR2.png";
	public static final String tx_alien_vert = "./ressources/AlienV1.png";
	public static final String tx_alien_vert_alt = "./ressources/AlienV2.png";
	public static final String tx_alien_jaune = "./ressources/AlienJ1.png";
	public static final String tx_alien_jaune_alt = "./ressources/AlienJ2.png";
}
