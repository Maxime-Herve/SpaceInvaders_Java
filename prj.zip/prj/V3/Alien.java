package v3.etu;

import poo1.y2021.engine.IObjAffichable;
import v3.etu.Alien;
import java.util.Random;

public class Alien implements IObjAffichable {

	/**
	 * Un alien est représenté par : • sa position horizontale nommée posX de type
	 * entier, • sa position verticale nommée posY de type entier, • sa vitesse de
	 * déplacement nommée cel de type entier, • ses points de vie nommée pv de type
	 * entier
	 */
	private int posX;
	private int posY;
	private int pv;
	private int color;
	private boolean count;
	private int chance;
	Random rnd;

	// Un alien peut avoir deux codes, donc deux textures possibles, donc cela
	// permet de faire une animation (option)
	private char CODE[] = { Constantes.code_alien_rouge, Constantes.code_alien_rouge_alt };
	private char CODE2[] = { Constantes.code_alien_jaune, Constantes.code_alien_jaune_alt };
	private char CODE3[] = { Constantes.code_alien_vert, Constantes.code_alien_vert_alt };
	// Sinon on peut ne gérer qu'un seul code comme pour le vaisseau
	// code=Constantes.code_alien_rouge;

	// Pour option: on change de texture toutes les 3 mises à jour de l'affichage
	private final int animationTimer = 2;

	// on remplace la célérité = vitesse de déplacement par un deltaX fixé à deux
	// pixels
	private final int deltaX = 4;

	/*
	 * la position intervient dans schéma de déplacement (une option à réaliser) la
	 * position permettra de compter le nombre possible de pixels maximal de
	 * déplacement entre le bord droit de l'écran et l'alien de droite
	 */
	private int position;

	/*
	 * on va incrémenter conteurAnimation à chaque mise à jour de l'affichage, une
	 * fois qu'il atteint animationTimer on change le sélecteur (on donne un autre
	 * code, donc une autre texture).
	 */
	private int compteurAnimation = 0, selecteurDeCode = 0;

	public Alien(int x, int y) {
		posX = x;
		posY = y;
		pv = 1;
		position = 0;
		chance = 100;
		count = true;
		rnd = new Random();
		int nb = rnd.nextInt(3);
		switch (nb) { // choisit la couleur aléatoirement
		case 0:
			color = 1;
			break;
		case 1:
			color = 2;
			break;

		case 2:
			color = 3;
			break;

		default:
			color = 1;
			break;
		}
	}
	
	public Alien(int x, int y, int chance) {
		posX = x;
		posY = y;
		pv = 1;
		position = 0;
		this.chance = 500/chance;
		count = true;
		rnd = new Random();
		int nb = rnd.nextInt(3);
		switch (nb) { // choisit la couleur en fonction de la ligne
		case 0:
			color = 1;
			break;
		case 1:
			color = 2;
			break;

		case 2:
			color = 3;
			break;

		default:
			color = 1;
			break;
		}
	}

	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	}

	public int getPosition() {
		return position;
	}

	public int getPv() {
		return pv;
	}

	public int getColor() {
		return color;
	}

	public char getCode() {
		// Option avant de retourner le code on met à jour notre animation
		majAnimation();
		// puis notre position (plusieurs options possibles de déplacements)
		deplacementV2();
		switch (color) {
		case 1:
			return CODE[selecteurDeCode];

		case 2:
			return CODE2[selecteurDeCode];

		case 3:
			return CODE3[selecteurDeCode];

		default:
			return CODE[selecteurDeCode];
		}
	}

	/*
	 * Le déplacement se base sur l'alien le plus à droite à l'initialisation, on
	 * garde cette régle même s'il meurt Le calcul se base sur des pixels écran
	 */
	@SuppressWarnings("unused")
	private void deplacementV1() {
		position += deltaX; // position en pixel

		if (position <= 344)
			posX += deltaX;
		else {
			posY += 10;
			posX -= 344;
			position = 0;
		}
		// System.out.println(position+" posX="+posX+" posY="+posY);
	}

	// Option à faire
	private void deplacementV2() {
		if ((position <= 344) && count) { // si se déplace vers la droite
			posX += deltaX;
			position += deltaX;
		} else if ((position >= deltaX) && !count) { // si ce déplace vers la gauche 
			posX -= deltaX;
			position -= deltaX; 
		} else { // si à atteint un côté de l'aire de jeux, descend et change de côté
			posY += 10;
			count=!count;
		}
	}

	/*
	 * Mise à jour animation des aliens en changeant le code l'Alien =
	 * autre texture à appeler dans getCode() qui est appelée dans l'update de l'UI
	 */
	private void majAnimation() {
		compteurAnimation++; 
		if (compteurAnimation == animationTimer) { // mise à jour de l'animation
			compteurAnimation = 0;
			switch(selecteurDeCode) {
				case 0 :
					selecteurDeCode = 1;
					break;
				case 1 :
					selecteurDeCode = 0;
					break;
			}
		}
	}
	
	public Projectile tirAlien() {
		int nb = rnd.nextInt(chance);
		Projectile projectile = null;
		if(nb==chance-1) {
			projectile = new Projectile(this);
		}
		return projectile;
	}

}
