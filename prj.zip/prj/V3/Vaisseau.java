package v3.etu;

import poo1.y2021.engine.IObjAffichable;

/* La classe Vaisseau est fournie 
Afin d'être affichable, elle utilise une librairie graphique (fournie)
La liaison (implements) avec la librairie graphique se fait avec l'interface IObjAffchable (notion vue en RT2)
*/
public class Vaisseau implements IObjAffichable {

	// Les coordonées x et y du vaisseau (le centre de l'image associée)
	private int x, y;
	/*
	 * Le code est utilisé pour l'affichage soit d'une texture (image) ou d'un
	 * rectangle de couleur en l'absence d'image
	 */
	private char code;
	// Compteur qui permet d'autoriser à nouveau un tir
	private int pretATirer;
	// deltaX est le déplacement en pixels
	private final int deltaX = 8;
	// pour empêcher de tirer en permanence (tous les 10 rafraichissements)
	private final int delaisRechargement = 3;
	
	private boolean deplacement;

	// constructeur
	public Vaisseau(int x, int y) {
		this.x = x;
		this.y = y;
		deplacement = true;
		code = Constantes.code_vaisseau;
		pretATirer = 0;
	}

	// les observateurs
	@Override
	public int getPosX() {
		return x;
	}

	@Override
	public int getPosY() {
		return y;
	}

	/**
	 * Retourne le code du vaisseau cf classe Constantes = '@'
	 */
	@Override
	public char getCode() {
		// à chaque mise à jour de l'affichage getCode est appelée
		// on incrémente pretATirer pour gérer le délai de tir toutes les 10 mises à
		// jour
		if (pretATirer < delaisRechargement)
			pretATirer++;
		return code;
	}

	/*
	 * actionVaisseau se décompose maintenant en trois méthodes, elles seront
	 * appellées directement depuis le jeu dans gestionCommandes()
	 */

	/**
	 * Le tir crée un projectile, il est crée si le délai de réarmement est écoulé
	 * 
	 * @return
	 */
	public Projectile tir() {
		Projectile projectile = null;
		if (pretATirer == delaisRechargement) {
			pretATirer = 0;
			projectile = new Projectile(this);
		}
		return projectile;
	}

	/**
	 * 
	 */
	public void deplacementGauche() {
		if (x > deltaX)
			x -= deltaX;
	}

	/**
	 * 
	 */
	public void deplacementDroite() {
		if (x < Jeu.largeur_jeu*0.95)
			x += deltaX;
	}
	
	public void deplacementAleatoireVaisseau() {
		if(deplacement) {
			if(x<=deltaX) {
				deplacement = !deplacement;
			} else {
				deplacementGauche();
			}
		} 
		if(!deplacement) {
			if(x>=(Jeu.largeur_jeu-deltaX-20)) {
				deplacement = !deplacement;
			} else {
				deplacementDroite();
			}
		} 
	}

}
