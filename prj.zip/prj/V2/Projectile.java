package v2.etu;

import poo1.y2021.engine.IObjAffichable;

// La classe projectile est fournie

public class Projectile implements IObjAffichable {

	// position du projectile
	private int x, y;
	private boolean tireur;
	// le projectile se déplace vers le haut de 5 pixels
	private final int deltaY = 5;

	/**
	 * Le projectile est crée par un autre objet (ici le vaisseau, on pourrait
	 * imaginer faire tirer les aliens (Bonus))
	 * 
	 * @param source
	 */
	@SuppressWarnings("unlikely-arg-type")
	public Projectile(IObjAffichable source) {
		x = source.getPosX();
		y = source.getPosY() - Jeu.hauteur_texture / 2;
		if(source.getClass().equals("Vaisseau")) {
			tireur = false;
		} else {
			tireur = true;
		}
	}

	@Override
	public int getPosX() {
		return x;
	}

	@Override
	public int getPosY() {
		return y;
	}

	@Override
	public char getCode() {
		// à chaque mise à jour de l'affichage getCode est appelée
		// à chaque update le projectile se déplace:
		if ((y > 0)&&tireur) {
			y -= deltaY;
		} else {
			y += deltaY;
		}
		return Constantes.code_projectile;
	}

}
