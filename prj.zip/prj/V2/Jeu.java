package v2.etu;

import java.awt.Rectangle;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import poo1.y2021.engine.Affichage;
import poo1.y2021.engine.IObjAffichable;

public class Jeu {
	// résolution de la scène proposée (faire un rectangle qui est redimensionnable)
	public static final int largeur_jeu = 600;
	public static final int hauteur_jeu = 400;
	public static final int nombreAlien = 21;
	public static final int espace_largeur = 10;
	public static final int espace_hauteur = 20;

	// résolution des textures proposées
	public static final int largeur_texture = 24;
	public static final int hauteur_texture = 16;
	private static final int temporisation = 100;// 32 ms <=> 30 images/seconde
	// objets du jeu
	private Affichage affichage;
	private Vaisseau vaisseau;
	private ArrayList<Alien> lesAliens;
	private ArrayList<Projectile> projectiles;

	/**
	 * on se sert du constructeur pour l'initialisation
	 * 
	 * @throws InterruptedException
	 */
	public Jeu() throws InterruptedException {
		// Affichage affichage = new Affichage(1280, 800); mode fenêtré pour debug
		affichage = new Affichage(0, 0); // plein écran
		affichage.definirScene(largeur_jeu, hauteur_jeu);

		// on définit les textures
		affichage.definirTexture(Constantes.code_vaisseau, Constantes.tx_vaisseau);
		affichage.definirTexture(Constantes.code_projectile, Constantes.tx_projectile);
		affichage.definirTexture(Constantes.code_alien_rouge, Constantes.tx_alien_rouge);
		affichage.definirTexture(Constantes.code_alien_rouge_alt, Constantes.tx_alien_rouge_alt);
		affichage.definirTexture(Constantes.code_alien_jaune, Constantes.tx_alien_jaune);
		affichage.definirTexture(Constantes.code_alien_jaune_alt, Constantes.tx_alien_jaune_alt);
		affichage.definirTexture(Constantes.code_alien_vert, Constantes.tx_alien_vert);
		affichage.definirTexture(Constantes.code_alien_vert_alt, Constantes.tx_alien_vert_alt);

		// on initialise les objets de base du jeu
		// un vaisseau
		vaisseau = new Vaisseau(largeur_jeu / 2, hauteur_jeu - 100);

		// Créer une liste de projectiles
		projectiles = new ArrayList<Projectile>();

		// Créer une liste d'Aliens
		lesAliens = new ArrayList<Alien>();
		int x = 0, y = 10, ligne = 0;

		// Ajouter dix aliens sur la scène (le premier en 32,10) et afficher dans la
		// console leur position initiale
		for (int i = 0; i < nombreAlien; i++) {
			ligne++;
			lesAliens.add(new Alien(x, y));
			x += largeur_jeu / nombreAlien + espace_largeur;
			if (ligne == 7) {
				y += espace_hauteur;
				x = 0;
				ligne = 0;
			}

			// information sur les aliens
			/*
			 * System.out.println("Alien N°" + (i + 1) + ", Postion X : " +
			 * lesAliens.get(i).getPosX() + ", Postion Y : " + lesAliens.get(i).getPosY() +
			 * ", Couelur : " + lesAliens.get(i).getColor());
			 */
		}

		// Ajouter les objets dans la scène
		// ajout du vaisseau
		affichage.addObject(vaisseau);

		// information sur le vaisseau
		/*
		 * System.out.println( "Position x du vaisseau : " + vaisseau.getPosX() +
		 * " Position Y du vaisseau : " + vaisseau.getPosY());
		 */

		// ajout des aliens
		for (int i = 0; i < nombreAlien; i++) {
			affichage.addObject(lesAliens.get(i));
		}

		// Afficher les directives dans la console "graphique"
		affichage.println("La touche [Echap] vous permet de quitter le jeu a tout moment");
		affichage.println("Utilisez les touches 'q' et 'd' pour déplacer votre vaisseau, espace pour tirer.");
		// l'initialisation est finie, on est prêt à lancer le jeu

	}

	/**
	 * Boucle de jeu
	 * 
	 * @throws InterruptedException
	 */
	public void boucleJeu() throws InterruptedException {
		int finDeJeu = 0, score = 0;
		while (finDeJeu == 0) {

			/*
			 * Réagir aux commandes de l'utilisateur à chaque boucle. C'est dans cette
			 * méthode que sera définie le rythme du jeu (temporisation)
			 */
			gestionCommandes();

			// Gérer la fin de vie des projectiles
			gestionProjectiles();

			// Tester la collision tir/aliens avec testCollision fournie et enlever ce qui
			// doit l'être
			testCollisionObject();

			// Tester si c'est la fin de la partie
			// victoire si tous les aliens sont morts, defaite s'ils sont passés.
			finDeJeu = finPartie(lesAliens, vaisseau);

			// TODO bonus : faire tirer les aliens & co ????????
			// mise à jour de l'affichage
			affichage.update();

			// affichage des infos sur les aliens lors des tests
			/*
			 * for (int i = 0; i < lesAliens.size(); i++) { System.out.println( "Alien N°" +
			 * (i + 1) + ", Postion : " + lesAliens.get(i).getPosition() + ", Postion X : "
			 * + lesAliens.get(i).getPosX() + ", Postion Y : " +
			 * lesAliens.get(i).getPosY()); }
			 */

			// affichage des infos sur les projectiles lors des tests
			/*for (int i = 0; i < projectiles.size(); i++) {
				System.out.println("Projecile N°" + i + ", Position Y : " + projectiles.get(i).getPosY());
			}*/

		}
		
		// A faire : afficher message final et quitter la partie
		score = nombreAlien-lesAliens.size();
		affichage.println(""+score);
		if(finDeJeu==1) {
			System.out.println("Vous avez perdu, votre score est de "+score);
		} else {
			System.out.println("Vous avez gagné, votre score est de "+score);
		}
	    String ecriture, lecture;
		try (Socket clientTCP = new Socket("127.0.0.1", 5000)) { // essai de ce connecter
			PrintWriter out = new PrintWriter(clientTCP.getOutputStream()); // Classe permettant ici d'écrire dans le
																			// réseau
			Scanner in = new Scanner(clientTCP.getInputStream()); // classe permettant ici d'écouter ce que l'on reçooit
																	// du réseau
			@SuppressWarnings("resource")
			Scanner entrer = new Scanner(System.in, "ISO-8859-1"); // classe permettant ici de récupérer la saisie
																	// clavier de 'utilisateur
			System.out.println("Lancement du client TCP @IP / Port" + clientTCP.getLocalSocketAddress() // Affichage des
																										// sockets
					+ " sur le serveur " + clientTCP.getRemoteSocketAddress());
			System.out.println("Veuillez saisir votre Pseudo : (6 caractères max) "); // affichage du message entrer
																						// votre pseudo
			ecriture = entrer.nextLine(); // Ecriture de l'utilisateur stocker dans une variable
			out.println(ecriture + " " + score); // Envoie du message au cache du réseau
			out.flush(); // on force l'envoie dans le réseau
			System.out.println("C->S : Envoie du pseudo du score calculé : " + ecriture + " " + score); // affichage du
																										// message
																										// d'envoei sur
			lecture = in.nextLine(); // Attente de réception du message du serveur
			System.out.println("S->C : " + lecture); // affichage de la réception
			clientTCP.close(); // fermeture du client
			System.out.println("fin de la connexion avec : " + clientTCP.getRemoteSocketAddress()); // envoie du message
																									// de fin de
																									// connexion
		} catch (Exception e) { // en cas d'erreur de connection, affiche le message erreur de connexion
			System.out.println("Erreur de connexion");
		}
		affichage.close();
	}

	// A faire
	/**
	 * Méthode qui prend en paramètre le tableau d’aliens et qui détermine si le jeu
	 * est terminé. Tel est le cas si un alien a atteint le niveau du vaisseau ou
	 * bien si tous les aliens sont détruits.
	 * 
	 * @param listeAliens
	 * @param vaisseau
	 * @return codeRetour 0: partie encours 1: aliens morts 2: vaisseau mort
	 */
	private int finPartie(List<Alien> listeAliens, Vaisseau vaisseau) {
		int codeRetour = 0; // variable d'information sur l'état de la partie
		if (listeAliens.size() == 0) { // Si tous les aliens sont tués
			codeRetour = 1; // code de retour = 1 (gagne)
		} else {
			for (int i = 0; i < lesAliens.size(); i++) { // Si un alien à atteint la hauteur du vaisseau
				if (vaisseau.getPosY() == lesAliens.get(i).getPosY()) { // vérifie qu'un alien est à la hauteur du
																		// vaisseau
					codeRetour = 2; // code de retour = 2 (perdu)
					break; // sortie de la boucle
				}
			}
		}
		return codeRetour; // envoie le code retour
	}

	// A Compléter, cette méthode permet de gérer les actions du vaisseau et de
	// créer les projectiles lors des tirs
	/**
	 * ATTENTION ! la méthode "AttenteDeTouche" s'occupe de détecter la touche echap
	 * et de fermer l'application dans ce cas. * On recupère une éventuelle
	 * commande, on la traite ... ATTENTION ! la méthode "AttenteDeTouche" s'occupe
	 * de détecter la touche Echap et de fermer l'application dans ce cas. On peut
	 * se permettre un while true pour le test
	 * 
	 */
	private void gestionCommandes() {
		int commande = affichage.AttenteDeTouche(temporisation);
		switch (commande) {
		case Affichage.CMD_ACTION: // A faire : créer un projectile en cas de tir et l'ajouter à la liste des
									// projectiles
			Projectile p = vaisseau.tir();
			if (p != null) {
				projectiles.add(p);
				affichage.addObject(projectiles.get(projectiles.size() - 1));
			}

			break;
		case Affichage.CMD_DROITE:
			vaisseau.deplacementDroite(); // déplacement du vaisseau à droite
			break;
		case Affichage.CMD_GAUCHE:
			vaisseau.deplacementGauche(); // déplacement du vaisseau à gauche
			break;
		default:
			if (commande > 0)
				/*
				 * System.out.println("UCMD : "+commande); //permet de connaître le code d'une
				 * touche
				 */
				break;
		}
	}

	// A faire
	/**
	 * Pour effacer les projectiles qui sortent de la fenêtre (y<0) Il faut les
	 * enlever de la liste des projectiles et de l'affichage
	 */
	private void gestionProjectiles() {
		for (int i = 0; i < projectiles.size(); i++) { // boucle de sélection des aliens
			if (projectiles.get(i).getPosY() < 0) { // Si le projectile arrive en haut de l'affichage
				affichage.removeObject(projectiles.get(i)); // supprime le projectile de l'affichage
				projectiles.remove(i); // supprime le projectile de la liste
				break; // sortie de la boucle
			}
		}
	}

	// methode statique fournie:
	/**
	 * renvoi true si l'ObjetAffichable "a" est en contact avec l'ObjetAffichable
	 * "b". Cette methode prend en compte le fait qu'un projectile est plus petit
	 * que les autres objets.
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	private static boolean testCollision(IObjAffichable a, IObjAffichable b) {
		Rectangle zoneA, zoneB;
		/*
		 * pour le vaisseau et les aliens on considère que la zone de contact est la
		 * texture par contre un projectile ne fait que 4 pixels de large, on détermine
		 * donc une zone plus petite. Pour rester simple dans ce cas, on ne prend qu'un
		 * pixel. Si vous utilisez des textures alternatives, il peut être nécessaire de
		 * revoir ces zones.
		 */
		if (a instanceof Projectile)
			zoneA = new Rectangle(a.getPosX() - largeur_texture / 2, a.getPosY(), 1, hauteur_texture);
		else
			zoneA = new Rectangle(a.getPosX(), a.getPosY(), largeur_texture, hauteur_texture);

		if (b instanceof Projectile)
			zoneB = new Rectangle(b.getPosX() + largeur_texture / 2, b.getPosY(), 1, hauteur_texture);
		else
			zoneB = new Rectangle(b.getPosX(), b.getPosY(), largeur_texture, hauteur_texture);
		// on a les bons rectangles, il reste à calculer l'intersection
		return zoneA.intersects(zoneB);
	}

	/**
	 * Test et supprime les Aliens et les projectiles qui rentrent en collision
	 */
	private void testCollisionObject() {
		boolean info = false; // variable d'info de collision
		for (int i = 0; i < projectiles.size(); i++) { // boucle de sélection des aliens
			for (int j = 0; j < lesAliens.size(); j++) { // boucle de sélection des projectiles
				if (testCollision(lesAliens.get(j), projectiles.get(i))) { // test une potentielle colision
					affichage.removeObject(lesAliens.get(j)); // supprime l'alien de l'affichage
					lesAliens.remove(j); // supprime l'alien de la liste
					affichage.removeObject(projectiles.get(i)); // supprime le projectile de l'affichage
					projectiles.remove(i); // supprime le projectile de la liste
					info = true; // informe qu'un alien à été supprimer
					break; // sortie de la boucle
				}
			}
		}
		if (info) { // en cas de collision
			/**
			 * La méthode se rappele d'elle même pour tester une potentielle deuxième
			 * collision, j'ai codé cette fonction de cette façon car sinon il pouvais y
			 * avoir des problèmes (la boucle selectionne un alien n'existant plus).
			 */
			testCollisionObject();
		}
	}

}
